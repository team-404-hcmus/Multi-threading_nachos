#include"syscall.h"

int main()
{
	int number;
	number = ReadInt();
	Halt();
}
